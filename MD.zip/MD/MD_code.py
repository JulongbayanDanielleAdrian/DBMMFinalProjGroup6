import sqlite3
import pandas as pd
import os

# Get the current directory where MD_code.py is located
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the path to MEDICINE.csv in the same folder
csv_path = os.path.join(script_dir, 'MEDICINE.csv')

# Check if the file exists before loading
if os.path.exists(csv_path):
    conn = sqlite3.connect('md_database.db')

    # Load CSV into SQLite Database
    df = pd.read_csv(csv_path)
    df.to_sql('md_table', conn, if_exists='replace', index=False)  # Save to SQLite

    conn.close()
    print(df.head())
else:
    print(f"Error: MEDICINE.csv not found in {script_dir}")