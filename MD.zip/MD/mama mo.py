import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import os

# Get the current directory where the script is located
script_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the path to MEDICINE.csv in the same folder
csv_path = os.path.join(script_dir, 'MEDICINE.csv')

# Connect to SQLite Database
conn = sqlite3.connect('md_database.db')
cursor = conn.cursor()

# Create Table if Not Exists
cursor.execute('''CREATE TABLE IF NOT EXISTS md_table (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    type TEXT,
    price REAL
)''')

# Check if Table is Empty & Populate Data from CSV if available
cursor.execute("SELECT COUNT(*) FROM md_table")
if cursor.fetchone()[0] == 0:
    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path)
            df.to_sql('md_table', conn, if_exists='append', index=False)
            conn.commit()
            print(f"Data loaded from {csv_path} into md_table.")
        except FileNotFoundError:
            print(f"Error: {csv_path} not found.")
        except Exception as e:
            print(f"Error loading CSV: {e}")
    else:
        # If no CSV, insert default medicines
        print("MEDICINE.csv not found. Inserting default medicines.")
        sample_data = [
            ("Paracetamol", "Tablet", 50.0),
            ("Ibuprofen", "Capsule", 75.0),
            ("Amoxicillin", "Syrup", 120.0),
            ("Cetirizine", "Tablet", 30.0),
            ("Metformin", "Tablet", 90.0)
        ]
        cursor.executemany("INSERT INTO md_table (name, type, price) VALUES (?, ?, ?)", sample_data)
        conn.commit()

conn.close()

# Function to Search Medicine
def search_medicine():
    search_term = entry.get()
    conn = sqlite3.connect('md_database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM md_table WHERE name LIKE '%{search_term}%'"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()

    # Clear previous results
    for row in tree.get_children():
        tree.delete(row)

    # Display search results
    if rows:
        for row in rows:
            tree.insert('', tk.END, values=row)
    else:
        messagebox.showinfo("No Results", "No medicine found with that name.")

# GUI Setup
root = tk.Tk()
root.title("Medicine Search")
root.geometry("600x400")

# Search Label & Entry
tk.Label(root, text="Enter Medicine Name:").pack(pady=5)
entry = tk.Entry(root)
entry.pack(pady=5)

# Search Button
tk.Button(root, text="Search", command=search_medicine).pack(pady=5)

# Table View
tree = ttk.Treeview(root, columns=("ID", "Name", "Type", "Price"), show="headings")
tree.pack(fill="both", expand=True)

# Set Column Headings
tree.heading("ID", text="ID")
tree.heading("Name", text="Name")
tree.heading("Type", text="Type")
tree.heading("Price", text="Price")

# Populate initial data in the Treeview
conn = sqlite3.connect('md_database.db')
cursor = conn.cursor()
cursor.execute("SELECT * FROM md_table")
initial_data = cursor.fetchall()
for row in initial_data:
    tree.insert('', tk.END, values=row)
conn.close()

root.mainloop()